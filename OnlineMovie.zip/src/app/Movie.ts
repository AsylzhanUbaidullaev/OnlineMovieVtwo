export class Movie {
  id: string;
  name: string;
  url: string;
}
